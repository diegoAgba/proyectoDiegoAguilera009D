from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(request):
    return render(request,  'core/home.html') 
from django.http import HttpResponse


def inicio(request):
    return HttpResponse("Esto se llama cuando se ven los productos/")

def productos(request):
    return HttpResponse("Ahora pediste productos /gracias por tu compra")

def agregar_producto(request):
    html = """
    <h1>Agregar producto</h1>
    <p>Podemos mostrar productos 
    <strong>plantillas</strong> y motores ;)</p>
    """
    return HttpResponse(html)   